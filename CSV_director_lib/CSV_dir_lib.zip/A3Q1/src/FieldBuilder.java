import java.util.List;

public interface FieldBuilder {
    public List<String> build();
}
