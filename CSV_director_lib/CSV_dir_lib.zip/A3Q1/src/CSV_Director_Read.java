import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class CSV_Director_Read extends CSV_Director {
    private CSV_Director_Read() {}

    // creates an instance of a reading director if no other directors exist(singleton)
    public static CSV_Director getInstance() {
        if (director == null) {
            director = new CSV_Director_Read();
        }
        return director;
    }

    // opens the file for reading
    protected void openFile(String filename) throws IOException {
        reader = new BufferedReader(new FileReader(filename));
    }

    // reads a line
    private String Read() throws IOException {
        String line = reader.readLine();
        return line;
    }

    // reads a line at the inputted line number
    @Override
    protected String execute() throws IOException {
        String record = "";
        for (int i = 0; i < lineToRead; i++) {
            record = Read();
            if (record == null) {
                throw new IllegalArgumentException("Error: line to read didn't exist. Last line number is " + i);
            }
        }
        return record;
    }
}
