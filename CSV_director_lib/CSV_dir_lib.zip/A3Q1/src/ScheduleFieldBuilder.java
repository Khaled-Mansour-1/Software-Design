import java.util.List;

public class ScheduleFieldBuilder implements FieldBuilder {

    // returns a list of the fields for the default schedule csv
    @Override
    public List<String> build() {
        return List.of("day", "startTime", "endTime", "class");
    }
}
