import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

public class CSV_Director_Write extends CSV_Director {
    private CSV_Director_Write() {
    }

    // creates an instance of a writing director if no other directors exist(singleton)
    public static CSV_Director getInstance() {
        if (director == null) {
            director = new CSV_Director_Write();
        }
        return director;
    }

    // opens the file for writing and adds the header line to the CSV file if its new
    protected void openFile(String filename) throws IOException {
        File f = new File(filename);
        boolean isEmpty = (f.length() == 0L) || !f.exists();
        writer = new BufferedWriter(new FileWriter(f, true));
        if (isEmpty) {
            String header = String.join(",", fields);
            writer.write(header);
            writer.newLine();
        }
    }

    // appends a line
    private void Write(String line) throws IOException {
        writer.write(line);
        writer.newLine();
    }

    // validates if the line inputted agrees with the structure of the CSV fields
    private void validateLine(List<String> record) {
        if (record.size() != fields.size()) {
            throw new IllegalArgumentException(
                    "Number of values does not match fields");
        }
    }

    // Does input validation and writes the line
    @Override
    protected String execute() throws IOException {
        List<String> record = Arrays.asList(this.line.split(","));
        validateLine(record);
        Write(line);
        return "";
    }
}