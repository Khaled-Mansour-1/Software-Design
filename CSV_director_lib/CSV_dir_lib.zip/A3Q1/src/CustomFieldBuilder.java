import java.util.List;

public class CustomFieldBuilder implements FieldBuilder {
    private String field1;
    private String field2;
    private String field3;

    public CustomFieldBuilder(String field1, String field2, String field3) {
        this.field1 = field1;
        this.field2 = field2;
        this.field3 = field3;
    }

    // change the custom fields
    public void reset(String field1, String field2, String field3) {
        this.field1 = field1;
        this.field2 = field2;
        this.field3 = field3;
    }

    // returns a list of the custom fields for the csv
    @Override
    public List<String> build() {
        return List.of(field1, field2, field3);
    }
}
