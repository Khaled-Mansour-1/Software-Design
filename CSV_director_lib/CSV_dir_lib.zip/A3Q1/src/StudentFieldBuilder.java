import java.util.List;

public class StudentFieldBuilder implements FieldBuilder {

    // returns a list of the fields for the default student csv
    @Override
    public List<String> build() {
        return List.of("firstName", "lastName", "degree", "CGPA");
    }
}
