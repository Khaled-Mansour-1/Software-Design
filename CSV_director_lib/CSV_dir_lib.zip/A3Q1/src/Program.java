import java.io.IOException;

public class Program {
    private static CSV_Director director;

    public static void main(String[] args) {
        try {
            // create a writing director and add a record
            director = CSV_Director_Write.getInstance();
            director.setLine("first,last,BSc. cs,2.0");
            director.process("students.csv", new StudentFieldBuilder());

            // reset director
            CSV_Director.reset();

            // create a reading director and read a line
            director = CSV_Director_Read.getInstance();
            director.setLineToRead(2);
            String line = director.process("students.csv", new StudentFieldBuilder());
            System.out.println(line);
        } catch (IOException e) {
            System.err.println("Error reading/writing to the file." + e.getMessage());
        } catch (IllegalArgumentException e) {
            System.err.println("Error: Incorrect record entered." + e.getMessage());
        }
    }
}
