import java.io.*;
import java.util.Arrays;
import java.util.List;


public abstract class CSV_Director {
    protected static CSV_Director director;
    protected BufferedReader reader;
    protected BufferedWriter writer;
    protected List<String> fields;
    protected String line;
    protected int lineToRead;

    public void setLineToRead(int lineToRead) {
        this.lineToRead = lineToRead;
    }

    public void setLine(String line) {
        this.line = line;
    }

    protected void closeFile() throws IOException {
        if (writer != null) writer.close();
        if (reader != null) reader.close();
    }

    // build the csv field structure
    private void defineFields(FieldBuilder fb) {
        fields = fb.build();
    }

    protected abstract String execute() throws IOException;

    protected abstract void openFile(String filename) throws IOException;

    // template method for the processing of a CSV file
    public final String process(String file, FieldBuilder fb) throws IOException {
        defineFields(fb);
        try {
            openFile(file);
            return execute();
        } finally {
            closeFile();
        }
    }

    // reset the singleton
    public static void reset() {
        director = null;
    }

}
