import java.awt.*;
import java.util.*;

/**
 * Implements an avatar motion algorithm through the interface, MotionAlgorithm.
 *
 * The avatar chooses a random direction and a random step distance for every move while avoiding collision with a wall, avatar
 * and/or obstacle.
 */
public class RandomMotion implements MotionAlgorithm {
    private Random rand;

    /**
     * Creates a RandomMotion algorithm by creating a Random() object which is used to generate random integers
     */
    public RandomMotion() {
        this.rand = new Random();
    }

    /**
     * moves the avatar in a random direction(horizontally, vertically, or diagonally) with random sized steps.
     *
     * @param avatar        The avatar to be moved
     * @param panelWidth    The width of the game panel
     * @param panelHeight   The height of the game panel
     * @param obstacles     List of all obstacles(rectangles) on the grid
     * @param avatars       List of all avatars on the grid(including the avatar to be moved)
     */
    public void move(Avatar avatar, int panelWidth, int panelHeight, java.util.List<Obstacle> obstacles, java.util.List<Avatar> avatars) {
        // calculate, randomly, the new change in x and y coordinates
        int dx = rand.nextInt(11) - 5;
        int dy = rand.nextInt(11) - 5;

        int size = avatar.getSize();
        int x    =    avatar.getX();
        int y    =    avatar.getY();

        // calculate the new coordinates
        int newX = Math.max(0, Math.min(x + dx, panelWidth - size));
        int newY = Math.max(0, Math.min(y + dy, panelHeight - size));

        Rectangle futureBounds = new Rectangle(newX, newY, size, size);

        // check if new coordinates will collide with any obstacles
        for (Obstacle obs : obstacles) {
            if (obs.getBounds().intersects(futureBounds)) {
                return;
            }
        }

        // check if new coordinates will collide with any avatars
        for (Avatar a : avatars) {
            if (a == avatar) continue;
            if (a.getBounds().intersects(futureBounds)) {
                return;
            }
        }

        // update avatar's coordinates
        avatar.setX(newX);
        avatar.setY(newY);
    }

}
