import java.awt.*;
import java.util.*;

/**
 * Implements an avatar motion algorithm through the interface, MotionAlgorithm.
 *
 * The avatar chooses a random direction and keeps going straight while avoiding collision with a wall, avatar,
 * and/or obstacle then chooses another random direction and keeps going straight. The avatar does this 4 times then stops moving.
 */
public class RandomLinearMotion implements MotionAlgorithm {
    /**
     * Possible directions to do(no diagonal movement).
     */
    private enum Direction { Up, Down, Left, Right }

    private Random rand;
    private final int maxMoves = 4;
    private int movesDone = 0;
    private Direction currentDir;

    /**
     * Creates a RandomLinearMotion algorithm by creating a Random() object which is used to generate random integers
     */
    public RandomLinearMotion() {
        this.rand = new Random();
    }

    /**
     * Randomly picks a direction for the avatar to go with.
     *
     * @return a direction from the enum 'Direction'
     */
    private Direction pickDir() {
        int r = rand.nextInt(4);

        // returns, randomly, one of the four directions
        switch (r) {
            case 0  : return    Direction.Up;
            case 1  : return  Direction.Down;
            case 2  : return  Direction.Left;
            default : return Direction.Right;
        }
    }

    /**
     * moves the avatar in a random direction(up, down, left, or right) and keeps going straight and stops if its about to collide
     *
     * @param avatar        The avatar to be moved
     * @param panelWidth    The width of the game panel
     * @param panelHeight   The height of the game panel
     * @param obstacles     List of all obstacles(rectangles) on the grid
     * @param avatars       List of all avatars on the grid(including the avatar to be moved)
     */
    public void move(Avatar avatar, int panelWidth, int panelHeight, java.util.List<Obstacle> obstacles, java.util.List<Avatar> avatars) {
        if (currentDir == null) {
            currentDir = pickDir();
        }

        int dx;
        int dy;

        // if avatar moved less than 4 times, make avatar keep going straight until it's about to collide
        // then switch direction and increment movesDone
        if (movesDone < maxMoves) {
            dx = 0;
            dy = 0;

            switch (currentDir) {
                case Up    : dy = -1; break;
                case Down  : dy =  1; break;
                case Left  : dx = -1; break;
                case Right : dx =  1; break;
            }

            // calculate the new coordinates
            int newX = Math.max(0, Math.min(avatar.getX() + dx, panelWidth - avatar.getSize()));
            int newY = Math.max(0, Math.min(avatar.getY() + dy, panelHeight - avatar.getSize()));

            Rectangle futureBounds = new Rectangle(newX, newY, avatar.getSize(), avatar.getSize());

            // check if the new calculated coordinates are the same as the current coordinates
            if (newX == avatar.getX() && newY == avatar.getY()) {
                movesDone++;
                currentDir = null;
                return;
            }

            // check if new coordinates will collide with any obstacles
            for (Obstacle obs : obstacles) {
                if (obs.getBounds().intersects(futureBounds)) {
                    movesDone++;
                    currentDir = null;
                    return;
                }
            }

            // check if new coordinates will collide with any avatars
            for (Avatar a : avatars) {
                if (a == avatar) continue;
                if (a.getBounds().intersects(futureBounds)) {
                    movesDone++;
                    currentDir = null;
                    return;
                }
            }

            // update avatar coordinates
            avatar.setX(newX);
            avatar.setY(newY);
        }
    }

}
