import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

public class TestRandomMotionGameWithObstacles {
    private RandomMotionGameWithObstacles game;

    @BeforeEach
    void setUp() {
        game = new RandomMotionGameWithObstacles();
    }

    @Test
    void testFrameTitleIsCorrect() {
        assertEquals("Random Motion Game with Obstacles", game.getTitle());
    }

    @Test
    void testFrameSizeIsCorrect() {
        assertEquals(800, game.getWidth());
        assertEquals(600, game.getHeight());
    }
}
