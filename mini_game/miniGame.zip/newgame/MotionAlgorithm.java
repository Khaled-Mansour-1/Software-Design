import java.awt.*;
import java.util.List;

/**
 * Interface/contract for all existing or future(to be added) motion algorithms.
 *
 * This defines how all and any implementation of a motion algorithm should behave.
 */
public interface MotionAlgorithm {

    /**
     * A function that updates an avatars position based on the algorithm's logic.
     * @param avatar        The avatar to be moved
     * @param panelWidth    The width of the game panel
     * @param panelHeight   The height of the game panel
     * @param obstacles     List of all obstacles(rectangles) on the grid
     * @param avatars       List of all avatars on the grid(including the avatar to be moved)
     */
    public void move(Avatar avatar, int panelWidth, int panelHeight, java.util.List<Obstacle> obstacles, java.util.List<Avatar> avatars);

}
