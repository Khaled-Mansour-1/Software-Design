import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

/**
 * Creates the game infrastructure.
 *
 * Initialises all avatars(and their assigned motion algorithm), obstacles, starting location of avatars/obstacles,
 * drawing and moving the avatars, and updating avatar motion.
 */
class GamePanel extends JPanel implements ActionListener {
    private final int NUM_AVATARS = 10;
    private final int AVATAR_SIZE = 20;
    private final java.util.List<Avatar> avatars;
    private final java.util.List<Obstacle> obstacles;
    private final javax.swing.Timer timer;

    /**
     * Creates the game panel, avatars(adding them to avatars list), obstacles(adding them to obstacles list).
     */
    public GamePanel() {
        setBackground(Color.BLACK);
        avatars     = new ArrayList<>();
        obstacles   = new ArrayList<>();
        Random rand = new      Random();

        MotionAlgorithm algorithm;
        int r;

        // creates avatars in random positions on the grid to populate the avatars list
        for (int i = 0; i < NUM_AVATARS; i++) {
            int x = rand.nextInt(800 - AVATAR_SIZE);
            int y = rand.nextInt(600 - AVATAR_SIZE);

            r = rand.nextInt(2);
            if (r == 0) {
                algorithm = new RandomMotion();
            } else {
                algorithm = new RandomLinearMotion();
            }

            avatars.add(new Avatar(x, y, AVATAR_SIZE, algorithm));
        }

        // create obstacles on the grid where avatars can't go through
        obstacles.add(new Obstacle(200, 150, 100, 200));
        obstacles.add(new Obstacle(500, 300, 150, 100));
        obstacles.add(new Obstacle(350, 50, 80, 80));

        timer = new javax.swing.Timer(100, this);
        timer.start();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        for (Obstacle obs : obstacles) {
            obs.draw(g);
        }
        for (Avatar avatar : avatars) {
            avatar.draw(g);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        for (Avatar avatar : avatars) {
            avatar.move(getWidth(), getHeight(), obstacles, avatars);
        }
        repaint();
    }
}