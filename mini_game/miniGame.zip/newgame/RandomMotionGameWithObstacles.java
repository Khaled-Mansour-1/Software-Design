import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

/**
 * Main window of the random motion game.
 * Initialises the game infrastructure by making a game panel.
 */

public class RandomMotionGameWithObstacles extends JFrame {
    /**
     * creates the main window, title of the game, size of the grid, and initialises a game panel
     */
    public RandomMotionGameWithObstacles() {
        setTitle("Random Motion Game with Obstacles");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        add(new GamePanel());
        setVisible(true);
    }

    /**
     * Launches the game
     *
     * @param args
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(RandomMotionGameWithObstacles::new);
    }
}