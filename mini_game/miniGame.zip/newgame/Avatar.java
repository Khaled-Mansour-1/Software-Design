import java.awt.*;
import java.util.*;

/**
 * This class creates an avatar.
 *
 * Saves each avatars' coordinates on the grid, the motion algorithm they use, and the avatars' color.
 */
class Avatar {
    private int x, y, size;
    private Color color;
    private Random rand;
    private MotionAlgorithm algorithm;

    /**
     * Constructs a new avatar
     *
     * @param x         x coordinate of the avatar
     * @param y         y coordinate of the avatar
     * @param size      size of the avatar(diameter)
     * @param algorithm the avatar's motion algorithm
     */
    public Avatar(int x, int y, int size, MotionAlgorithm algorithm) {
        this.x         = x;
        this.y         = y;
        this.size      = size;
        this.algorithm = algorithm;
        this.rand      = new Random();
        this.color     = new Color(randColor(), randColor(), randColor());
    }

    /**
     * Generates a random color for the avatar
     * @return a random integer(100-255) representing the avatar's color
     */
    private int randColor() {
        return 100 + rand.nextInt(156);
    }

    /**
     * Updates the avatars position using its assigned motion algorithm
     *
     * @param panelWidth    width of the game panel
     * @param panelHeight   height of the game ponel
     * @param obstacles     list of obstacles on the grind
     * @param avatars       list of avatars on the grid
     */
    public void move(int panelWidth, int panelHeight, java.util.List<Obstacle> obstacles, java.util.List<Avatar> avatars) {
        algorithm.move(this, panelWidth, panelHeight, obstacles, avatars);
    }

    /**
     * Draws/displays the avatar on the grid
     *
     * @param g
     */
    public void draw(Graphics g) {
        g.setColor(color);
        g.fillOval(x, y, size, size);
    }

    public int getX() {
        return this.x;
    }

    public void setX(int newX) {
        this.x = newX;
    }

    public int getY() {
        return this.y;
    }

    public void setY(int newY) {
        this.y = newY;
    }

    public int getSize() {
        return this.size;
    }

    /**
     * Creates an avatar object representing the obstacle's dimensions and position.
     *
     * @return a rectangle with same dimensions and size aas the avatar
     */
    public Rectangle getBounds() {
        return new Rectangle(x, y, size, size);
    }
}