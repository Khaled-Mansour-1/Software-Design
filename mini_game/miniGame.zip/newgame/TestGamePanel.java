import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

public class TestGamePanel {
    private GamePanel gamePanel;

    @BeforeEach
    void setUp() {
        gamePanel = new GamePanel();
    }

    @Test
    void testNotNull () {
        assertNotNull(gamePanel);
    }

    @Test
    void testActionPerformedDoesNotThrow() {
        assertDoesNotThrow(() -> gamePanel.actionPerformed(new ActionEvent(this, 0, "")));
    }

    @Test
    void testBackgroundColor () {
        assertEquals(Color.BLACK, gamePanel.getBackground());
    }
}
