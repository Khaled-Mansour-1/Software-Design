import java.util.*;
import java.util.List;
import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.assertTrue;


public class TestRandomMotion {
    private Avatar avatar;
    private List<Obstacle> obstacles;
    private List<Avatar> avatars;
    private RandomMotion algorithm;

    @BeforeEach
    void setup() {
        algorithm = new RandomMotion();
        avatar = new Avatar(100, 100, 20, algorithm);
        obstacles = new ArrayList<>();
        avatars = new ArrayList<>();
        avatars.add(avatar);
    }

    // tests that avatar doesn't escape the game panel boundaries
    @Test
    void testAvatarStaysWithinWalls() {
        avatar.setX(0);
        avatar.setY(0);

        for (int i = 0; i < 50; i++) {
            avatar.move(800, 600, obstacles, avatars);
            assertTrue(avatar.getX() >= 0 && avatar.getX()<= 800, "Avatar out of bounds(X-coord)");
            assertTrue(avatar.getY() >= 0 && avatar.getY()<= 600, "Avatar out of bounds(Y-coord)");
        }
    }

    // tests that avatars don't move if they collide with an obstacle
    @Test
    void testNoMovementIfObstacleCollision() {
        int initialX = avatar.getX();
        int initialY = avatar.getY();

        obstacles.add(new Obstacle(100, 100, 20, 20));

        for (int i = 0; i < 10; i++) {
            avatar.move(800, 600, obstacles, avatars);
        }

        assertTrue((avatar.getX() == initialX) && (avatar.getY() == initialY), "Avatar moved after collision with obstacle");
    }

    // tests that avatars don't move if they collide with another avatar
    @Test
    void testNoMovementIfAvatarCollision() {
        int initialX = avatar.getX();
        int initialY = avatar.getY();

        avatars.add(new Avatar(100, 100, 20, algorithm));

        for (int i = 0; i < 10; i++) {
            avatar.move(800, 600, obstacles, avatars);
        }

        assertTrue((avatar.getX() == initialX) && (avatar.getY() == initialY), "Avatar moved after collision with another avatar");
    }
}
