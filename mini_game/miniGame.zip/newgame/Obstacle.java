import java.awt.*;

/**
 * This class creates an obstacle(rectangle)
 *
 * It acts as a barrier in on the grid where avatars can't collide with or move through.
 * Saves the coordinates of the obstacle and its dimensions(size)
 */
class Obstacle {
    private int x, y, width, height;
    private Color color = Color.GRAY;

    /**
     *
     * @param x         x coordinate the rectangle's corner
     * @param y         y coordinate of the rectangle's corner
     * @param width     width of the rectangle
     * @param height    height of the rectangle
     */
    public Obstacle(int x, int y, int width, int height) {
        this.x      =      x;
        this.y      =      y;
        this.width  =  width;
        this.height = height;
    }

    /**
     * Creates a Rectangle object representing the obstacle's dimensions and position
     * @return a rectangle with same dimensions and coordinates as the obstacle
     */
    public Rectangle getBounds() {
        return new Rectangle(x, y, width, height);
    }

    /**
     * Draws/displays the obstacle
     * @param g
     */
    public void draw(Graphics g) {
        g.setColor(color);
        g.fillRect(x, y, width, height);
    }
}