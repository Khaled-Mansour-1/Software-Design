import java.awt.*;
import java.util.*;
import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestAvatar {
    private MotionAlgorithm algorithm;
    private Avatar avatar;

    @BeforeEach
    void setUp() {
        algorithm = new RandomMotion();
        avatar = new Avatar(100, 101, 20, algorithm);
    }

    @Test
    void testConstructor() {
        assertEquals(100, avatar.getX(), "Error in constructor");
        assertEquals(101, avatar.getY(), "Error in constructor");
        assertEquals(20, avatar.getSize(), "Error in constructor");
    }

    @Test
    void testSettersAndGetters() {
        avatar.setX(150);
        avatar.setY(200);

        assertEquals(150, avatar.getX(), "Error in getX()");
        assertEquals(200, avatar.getY(), "Error in getY()");
        assertEquals(20, avatar.getSize(), "Error in getSize()");
    }

    @Test
    void testGetBounds() {
        Rectangle bounds = avatar.getBounds();

        assertEquals(100, bounds.x, "Error in getBounds()");
        assertEquals(101, bounds.y, "Error in getBounds()");
        assertEquals(20, bounds.width, "Error in getBounds()");
        assertEquals(20, bounds.height, "Error in getBounds()");
    }
}
