import java.awt.*;
import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

public class TestObstacle {
    private Obstacle obstacle;

    @BeforeEach
    void setUp() {
        obstacle = new Obstacle(100, 101, 80, 40);
    }

    @Test
    void testConstructor() {
        Rectangle bounds = obstacle.getBounds();
        assertEquals(100, bounds.x, "Error in constructor");
        assertEquals(101, bounds.y, "Error in constructor");
        assertEquals(80, bounds.width, "Error in constructor");
        assertEquals(40, bounds.height, "Error in constructor");
    }

    @Test
    void testGetBounds() {
        Rectangle bounds = obstacle.getBounds();

        assertEquals(100, bounds.x, "Error in getBounds()");
        assertEquals(101, bounds.y, "Error in getBounds()");
        assertEquals(80, bounds.width, "Error in getBounds()");
        assertEquals(40, bounds.height, "Error in getBounds()");
    }
}
